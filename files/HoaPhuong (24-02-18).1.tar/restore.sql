--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.warehouse DROP CONSTRAINT warehouse_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.unknowproduct DROP CONSTRAINT unknowproduct_pkey;
ALTER TABLE ONLY public.sales DROP CONSTRAINT sales_pkey;
ALTER TABLE ONLY public.purchasesitems DROP CONSTRAINT purchasesitems_pkey;
ALTER TABLE ONLY public.purchases DROP CONSTRAINT purchases_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.catalogs DROP CONSTRAINT catalogs_pkey;
ALTER TABLE ONLY public.bills DROP CONSTRAINT bills_pkey;
ALTER TABLE ONLY public.barcodecmd DROP CONSTRAINT barcodecmd_pkey;
ALTER TABLE public.warehouse ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.unknowproduct ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.sales ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.purchasesitems ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.purchases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.catalogs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.bills ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.barcodecmd ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.warehouse_id_seq;
DROP TABLE public.warehouse;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.unknowproduct_id_seq;
DROP TABLE public.unknowproduct;
DROP SEQUENCE public.sales_id_seq;
DROP TABLE public.sales;
DROP SEQUENCE public.purchasesitems_id_seq;
DROP TABLE public.purchasesitems;
DROP SEQUENCE public.purchases_id_seq;
DROP TABLE public.purchases;
DROP SEQUENCE public.products_id_seq;
DROP TABLE public.products;
DROP SEQUENCE public.catalogs_id_seq;
DROP TABLE public.catalogs;
DROP SEQUENCE public.bills_id_seq;
DROP TABLE public.bills;
DROP SEQUENCE public.barcodecmd_id_seq;
DROP TABLE public.barcodecmd;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: barcodecmd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE barcodecmd (
    id integer NOT NULL,
    barcodecmd character varying(30),
    action character varying(30),
    descriptioncmd character varying(100)
);


ALTER TABLE barcodecmd OWNER TO postgres;

--
-- Name: barcodecmd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE barcodecmd_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE barcodecmd_id_seq OWNER TO postgres;

--
-- Name: barcodecmd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE barcodecmd_id_seq OWNED BY barcodecmd.id;


--
-- Name: bills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE bills (
    id integer NOT NULL,
    pricetotal integer,
    pricereceive integer,
    statusbill boolean,
    sellerid integer,
    barcodebill character varying(20),
    createdatb timestamp without time zone DEFAULT now()
);


ALTER TABLE bills OWNER TO postgres;

--
-- Name: bills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE bills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bills_id_seq OWNER TO postgres;

--
-- Name: bills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE bills_id_seq OWNED BY bills.id;


--
-- Name: catalogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE catalogs (
    id integer NOT NULL,
    namecatalog character varying(90),
    descriptioncatalog character varying(90),
    barcodecatalog character varying(20),
    createdatc timestamp without time zone DEFAULT now()
);


ALTER TABLE catalogs OWNER TO postgres;

--
-- Name: catalogs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE catalogs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE catalogs_id_seq OWNER TO postgres;

--
-- Name: catalogs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE catalogs_id_seq OWNED BY catalogs.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE products (
    id integer NOT NULL,
    nameproduct character varying(90),
    catalogid integer,
    barcodeproduct character varying(20),
    descriptionproduct character varying(100),
    location character varying(50),
    priceorigin integer,
    pricesell integer,
    unit character varying(10),
    createdatp timestamp without time zone DEFAULT now()
);


ALTER TABLE products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE products_id_seq OWNED BY products.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE purchases (
    id integer NOT NULL,
    barcodepur character varying(20),
    supplierid integer,
    paymentstatus integer,
    grandtotal integer,
    paid integer,
    createdatp timestamp without time zone DEFAULT now(),
    note character varying(200),
    usercreated integer
);


ALTER TABLE purchases OWNER TO postgres;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE purchases_id_seq OWNER TO postgres;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE purchases_id_seq OWNED BY purchases.id;


--
-- Name: purchasesitems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE purchasesitems (
    id integer NOT NULL,
    purchasesid integer,
    productid integer,
    quantitypur integer,
    subtotal integer,
    origincost integer,
    sellcost integer
);


ALTER TABLE purchasesitems OWNER TO postgres;

--
-- Name: purchasesitems_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE purchasesitems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE purchasesitems_id_seq OWNER TO postgres;

--
-- Name: purchasesitems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE purchasesitems_id_seq OWNED BY purchasesitems.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE sales (
    id integer NOT NULL,
    productid integer,
    quantitys integer,
    pricesell integer,
    priceorigin integer,
    billid integer
);


ALTER TABLE sales OWNER TO postgres;

--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sales_id_seq OWNER TO postgres;

--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sales_id_seq OWNED BY sales.id;


--
-- Name: unknowproduct; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE unknowproduct (
    id integer NOT NULL,
    barcodeunknow character varying(20)
);


ALTER TABLE unknowproduct OWNER TO postgres;

--
-- Name: unknowproduct_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE unknowproduct_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE unknowproduct_id_seq OWNER TO postgres;

--
-- Name: unknowproduct_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE unknowproduct_id_seq OWNED BY unknowproduct.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(30),
    password character varying(35),
    fullname character varying(90),
    barcodeuser character varying(10),
    type integer,
    createdat timestamp without time zone DEFAULT now()
);


ALTER TABLE users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE warehouse (
    id integer NOT NULL,
    productid integer,
    quantitysold integer,
    remainingamount integer
);


ALTER TABLE warehouse OWNER TO postgres;

--
-- Name: warehouse_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE warehouse_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE warehouse_id_seq OWNER TO postgres;

--
-- Name: warehouse_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE warehouse_id_seq OWNED BY warehouse.id;


--
-- Name: barcodecmd id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY barcodecmd ALTER COLUMN id SET DEFAULT nextval('barcodecmd_id_seq'::regclass);


--
-- Name: bills id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY bills ALTER COLUMN id SET DEFAULT nextval('bills_id_seq'::regclass);


--
-- Name: catalogs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY catalogs ALTER COLUMN id SET DEFAULT nextval('catalogs_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products ALTER COLUMN id SET DEFAULT nextval('products_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY purchases ALTER COLUMN id SET DEFAULT nextval('purchases_id_seq'::regclass);


--
-- Name: purchasesitems id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY purchasesitems ALTER COLUMN id SET DEFAULT nextval('purchasesitems_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sales ALTER COLUMN id SET DEFAULT nextval('sales_id_seq'::regclass);


--
-- Name: unknowproduct id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY unknowproduct ALTER COLUMN id SET DEFAULT nextval('unknowproduct_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: warehouse id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse ALTER COLUMN id SET DEFAULT nextval('warehouse_id_seq'::regclass);


--
-- Data for Name: barcodecmd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY barcodecmd (id, barcodecmd, action, descriptioncmd) FROM stdin;
\.
COPY barcodecmd (id, barcodecmd, action, descriptioncmd) FROM '$$PATH$$/2226.dat';

--
-- Name: barcodecmd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('barcodecmd_id_seq', 8, true);


--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY bills (id, pricetotal, pricereceive, statusbill, sellerid, barcodebill, createdatb) FROM stdin;
\.
COPY bills (id, pricetotal, pricereceive, statusbill, sellerid, barcodebill, createdatb) FROM '$$PATH$$/2208.dat';

--
-- Name: bills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('bills_id_seq', 144, true);


--
-- Data for Name: catalogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY catalogs (id, namecatalog, descriptioncatalog, barcodecatalog, createdatc) FROM stdin;
\.
COPY catalogs (id, namecatalog, descriptioncatalog, barcodecatalog, createdatc) FROM '$$PATH$$/2220.dat';

--
-- Name: catalogs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('catalogs_id_seq', 19, true);


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY products (id, nameproduct, catalogid, barcodeproduct, descriptionproduct, location, priceorigin, pricesell, unit, createdatp) FROM stdin;
\.
COPY products (id, nameproduct, catalogid, barcodeproduct, descriptionproduct, location, priceorigin, pricesell, unit, createdatp) FROM '$$PATH$$/2222.dat';

--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('products_id_seq', 838, true);


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY purchases (id, barcodepur, supplierid, paymentstatus, grandtotal, paid, createdatp, note, usercreated) FROM stdin;
\.
COPY purchases (id, barcodepur, supplierid, paymentstatus, grandtotal, paid, createdatp, note, usercreated) FROM '$$PATH$$/2216.dat';

--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('purchases_id_seq', 9, true);


--
-- Data for Name: purchasesitems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY purchasesitems (id, purchasesid, productid, quantitypur, subtotal, origincost, sellcost) FROM stdin;
\.
COPY purchasesitems (id, purchasesid, productid, quantitypur, subtotal, origincost, sellcost) FROM '$$PATH$$/2218.dat';

--
-- Name: purchasesitems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('purchasesitems_id_seq', 9, true);


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sales (id, productid, quantitys, pricesell, priceorigin, billid) FROM stdin;
\.
COPY sales (id, productid, quantitys, pricesell, priceorigin, billid) FROM '$$PATH$$/2210.dat';

--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sales_id_seq', 243, true);


--
-- Data for Name: unknowproduct; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY unknowproduct (id, barcodeunknow) FROM stdin;
\.
COPY unknowproduct (id, barcodeunknow) FROM '$$PATH$$/2214.dat';

--
-- Name: unknowproduct_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('unknowproduct_id_seq', 160, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id, username, password, fullname, barcodeuser, type, createdat) FROM stdin;
\.
COPY users (id, username, password, fullname, barcodeuser, type, createdat) FROM '$$PATH$$/2212.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_id_seq', 2, true);


--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY warehouse (id, productid, quantitysold, remainingamount) FROM stdin;
\.
COPY warehouse (id, productid, quantitysold, remainingamount) FROM '$$PATH$$/2224.dat';

--
-- Name: warehouse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('warehouse_id_seq', 6, true);


--
-- Name: barcodecmd barcodecmd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY barcodecmd
    ADD CONSTRAINT barcodecmd_pkey PRIMARY KEY (id);


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (id);


--
-- Name: catalogs catalogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY catalogs
    ADD CONSTRAINT catalogs_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: purchasesitems purchasesitems_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY purchasesitems
    ADD CONSTRAINT purchasesitems_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: unknowproduct unknowproduct_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY unknowproduct
    ADD CONSTRAINT unknowproduct_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse
    ADD CONSTRAINT warehouse_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

